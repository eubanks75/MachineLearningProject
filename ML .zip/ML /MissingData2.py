# -*- coding: utf-8 -*-
"""
@author: Danny
"""

from pandas import read_csv
import numpy as np
from sklearn.preprocessing import Imputer
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
from sklearn.preprocessing import LabelEncoder


dataset = read_csv('MissingData2.txt',header=None,delimiter='\t')
print(dataset.describe())
print((dataset[0:758] == 0).sum())
#Mark zero values as missing
dataset = dataset.replace(1.0000000000000001e+99,np.NaN)
dataset = dataset.fillna(dataset.mean())
print(dataset.head(20))
print(dataset.isnull().sum())

#split dataset into inputs and outputs
values = dataset.values
x = values[:,0:49]
y = values[:,49]
label_encoder = LabelEncoder()
label_encoder = label_encoder.fit(y)
label_encoded_y = label_encoder.transform(y)

imputer = Imputer()
trans_x = imputer.fit_transform(x)
model = LinearDiscriminantAnalysis()
kfold = KFold(n_splits = 3, random_state = 7)
result = cross_val_score(model, trans_x, label_encoded_y, cv=kfold, scoring='accuracy')
print(result.mean())
print(result)

dataset.to_csv('NguyenOhMissingResult2.txt', header=False, index=False)