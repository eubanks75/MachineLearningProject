import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier

train_data1 = pd.read_csv("TrainData1.csv", delimiter=" ", header=None)
train_labels1 = pd.read_csv("TrainLabel1.csv", delimiter=" ", header=None)
test_data1 = pd.read_csv("TestData1.csv", delimiter=" ", header=None)

train, test, train_labels, test_labels = train_test_split(train_data1, train_labels1, test_size=.75, random_state=22)

clf1 = DecisionTreeClassifier(max_depth=15)
clf1.fit(train, train_labels)
#predictions = clf1.predict(test)
#print(accuracy_score(test_labels, predictions))

result = clf1.predict(test_data1)

with open("NguyenOhClassification1.txt", 'w') as f:
    f.write("\n".join(map(str, result)))
