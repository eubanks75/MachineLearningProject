import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

from sklearn import linear_model

import fileinput

train_data5 = pd.read_csv("TrainData5.txt", delimiter=" ", header=None)
train_labels5 = pd.read_csv("TrainLabel5.txt", delimiter=" ", header=None)
test_data5 = pd.read_csv("TestData5.txt", delimiter=" ", header=None)

train, test, train_labels, test_labels = train_test_split(train_data5, train_labels5, test_size=.75, random_state=25)

logreg = linear_model.LogisticRegression(C=1e6)
logreg.fit(train, train_labels.values.ravel())
#predictions = logreg.predict(test)
#print(accuracy_score(test_labels, predictions))

result = logreg.predict(test_data5)

with open("NguyenOhClassification5.txt", 'w') as f:
    f.write("\n".join(map(str, result)))
