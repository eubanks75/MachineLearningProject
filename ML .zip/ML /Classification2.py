import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

#Feature Selection imports
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.feature_selection import chi2

# To deal with missing values
from sklearn.preprocessing import Imputer

from sklearn.tree import DecisionTreeClassifier

train_data2 = pd.read_csv("TrainData2.txt", delimiter="\t", header=None)
train_labels2 = pd.read_csv("TrainLabel2.txt", delimiter="\t", header=None)
test_data2 = pd.read_csv("TestData2.txt", delimiter="\t", header=None)

train_data2.replace(1.0000000000000001e+99, np.nan, inplace=True)
imp = Imputer(missing_values='NaN', strategy='mean', axis=0)
train_data2 = pd.DataFrame(imp.fit_transform(train_data2))

test_data2.replace(1.0000000000000001e+99, np.nan, inplace=True)
imp = Imputer(missing_values='NaN', strategy='mean', axis=0)
test_data2 = pd.DataFrame(imp.fit_transform(test_data2))

selector = (SelectKBest(chi2, k=100).fit(train_data2, train_labels2))
mask = selector.get_support()
new_features = []

for bool, feature in zip(mask, train_data2):
    if bool:
        new_features.append(feature)
new_train2 = pd.DataFrame(train_data2, columns=new_features)
new_test2 = test_data2[new_features]

train, test, train_labels, test_labels = train_test_split(new_train2, train_labels2, test_size=.5, random_state=22)

clf1 = DecisionTreeClassifier(max_depth=50)
clf1.fit(train, train_labels)
#predictions = clf1.predict(test)
#print(accuracy_score(test_labels, predictions))

result = clf1.predict(new_test2)

# output formatting
with open("NguyenOhClassification2.txt", 'w') as f:
    f.write("\n".join(map(str, result)))
