import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2

from sklearn import linear_model

import fileinput

train_data3 = pd.read_fwf("TrainData3.txt", colspecs='infer', header=None)
train_labels3 = pd.read_csv("TrainLabel3.txt", delimiter=",", header=None)
test_data3 = pd.read_fwf("TestData3.txt", colspecs='infer', header=None)

train, test, train_labels, test_labels = train_test_split(train_data3, train_labels3, test_size=.5, random_state=22)

selector = (SelectKBest(chi2, k=100).fit(train_data3, train_labels3))
mask = selector.get_support()
new_features = []

for bool, feature in zip(mask, train_data3):
    if bool:
        new_features.append(feature)
new_train3 = pd.DataFrame(train_data3, columns=new_features)
new_test3 = test_data3[new_features]

train, test, train_labels, test_labels = train_test_split(new_train3, train_labels3, test_size=.5, random_state=22)

logreg = linear_model.LogisticRegression(C=1e5)
logreg.fit(train, train_labels.values.ravel())
#predictions = logreg.predict(test)
#print(accuracy_score(test_labels, predictions))
result = logreg.predict(new_test3)

# output formatting
with open("NguyenOhClassification3.txt", 'w') as f:
    f.write("\n".join(map(str, result)))
