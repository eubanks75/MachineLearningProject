import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# To deal with missing values
from sklearn.preprocessing import Imputer

from sklearn import neighbors

train_data4 = pd.read_csv("TrainData4.txt", delimiter="\t", header=None)
train_labels4 = pd.read_csv("TrainLabel4.txt", delimiter="\t", header=None)
test_data4 = pd.read_csv("TestData4.txt", delimiter=",", header=None)

train_data4.replace(1.0000000000000001e+99, np.nan, inplace=True)

df = train_data4.join(train_labels4, rsuffix='13')
df = df.dropna()

new_train4 = df[df.columns[0:13]]
new_labels4 = df[df.columns[13:14]]

train, test, train_labels, test_labels = train_test_split(new_train4, new_labels4, test_size=.75, random_state=15)

knn = neighbors.KNeighborsClassifier(5)
knn.fit(train, train_labels.values.ravel())
#pred = knn.predict(test)
#print(accuracy_score(test_labels, pred))

result = knn.predict(test_data4)
with open("NguyenOhClassification4.txt", 'w') as f:
    f.write("\n".join(map(str, result)))
